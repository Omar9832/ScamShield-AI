// Keep in sync with backend/src/types.ts (move to a shared package later)
export type RiskLevel = "low" | "medium" | "high";

export interface AnalysisResult {
  riskScore: number;
  riskLevel: RiskLevel;
  topCategory: string;
  categories: { label: string; probability: number }[];
  signals: { term: string; weight: number }[];
  flags: { id: string; label: string }[];
  modelVersion: string;
}
