import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { analyzeMessage } from "../api";

const MAX = 2000;

export default function Welcome() {
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  async function onSubmit() {
    setLoading(true);
    setError(null);
    try {
      const result = await analyzeMessage(message);
      navigate("/dashboard", { state: { message, result } });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="container">
      <h1>ScamGuard</h1>
      <p className="muted">Paste a suspicious text message to see how likely it is to be a scam.</p>
      <textarea
        value={message}
        maxLength={MAX}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="e.g. USPS: your package could not be delivered. Pay a $1.99 fee: bit.ly/3xK9a"
        rows={7}
      />
      <div className="row">
        <span className="muted">{message.length}/{MAX}</span>
        <button disabled={loading || !message.trim()} onClick={onSubmit}>
          {loading ? "Analyzing…" : "Analyze message"}
        </button>
      </div>
      {error && <p className="error">{error}</p>}
    </main>
  );
}
