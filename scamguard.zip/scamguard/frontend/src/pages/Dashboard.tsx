import { Link, Navigate, useLocation } from "react-router-dom";
import type { AnalysisResult } from "../types";

interface State { message: string; result: AnalysisResult }

const pretty = (s: string) => s.replace(/_/g, " ");

export default function Dashboard() {
  const state = useLocation().state as State | null;
  if (!state) return <Navigate to="/" replace />; // e.g. page refreshed or opened directly

  const { message, result } = state;
  const scamCats = result.categories.filter((c) => c.label !== "legitimate");
  const maxWeight = Math.max(...result.signals.map((s) => s.weight), 0.001);

  return (
    <main className="container">
      <Link to="/">← Analyze another message</Link>

      <section className={`card risk ${result.riskLevel}`}>
        <div className="score">{result.riskScore}<small>/100</small></div>
        <div>
          <h2>{result.riskLevel.toUpperCase()} RISK</h2>
          {result.riskLevel !== "low" && (
            <p>Most likely type: <strong>{pretty(result.topCategory)}</strong></p>
          )}
        </div>
        <div className="meter"><div style={{ width: `${result.riskScore}%` }} /></div>
      </section>

      <section className="card">
        <h3>Message</h3>
        <blockquote>{message}</blockquote>
      </section>

      <section className="card">
        <h3>Scam type breakdown</h3>
        {scamCats.map((c) => (
          <div className="bar-row" key={c.label}>
            <span>{pretty(c.label)}</span>
            <div className="bar"><div style={{ width: `${c.probability * 100}%` }} /></div>
            <span>{(c.probability * 100).toFixed(0)}%</span>
          </div>
        ))}
      </section>

      <section className="card">
        <h3>Red flags</h3>
        {result.flags.length === 0 ? <p className="muted">No heuristic red flags found.</p> : (
          <ul>{result.flags.map((f) => <li key={f.id}>{f.label}</li>)}</ul>
        )}
      </section>

      <section className="card">
        <h3>Words that raised the score</h3>
        {result.signals.length === 0 ? <p className="muted">None.</p> : result.signals.map((s) => (
          <div className="bar-row" key={s.term}>
            <span>“{s.term}”</span>
            <div className="bar"><div style={{ width: `${(s.weight / maxWeight) * 100}%` }} /></div>
            <span />
          </div>
        ))}
      </section>

      <p className="muted">Model version {result.modelVersion}. Scores are estimates, not guarantees.</p>
    </main>
  );
}
