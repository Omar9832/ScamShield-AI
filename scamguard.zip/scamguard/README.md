# ScamGuard

```
Browser (React TS) ──/api/analyze──▶ Backend (Node TS, :4000) ──/predict──▶ Model service (Python, :8000)
                                                                               └─ loads ml/artifacts/model.joblib
```

## Run it (3 terminals)
```bash
# 1. Train once, then serve the model
cd ml && pip install -r requirements.txt
python generate_data.py && python train.py
uvicorn serve:app --port 8000

# 2. Backend
cd backend && npm install && npm run dev

# 3. Frontend
cd frontend && npm install && npm run dev     # http://localhost:5173
```

## Swapping in the real data/classifier
- Put the provided CSV at `ml/data/messages.csv` (columns `text,label`; one label must be `legitimate`).
- Replace the pipeline in `ml/train.py` with the baseline classifier.
- Keep the artifact contract: `model.joblib` + `metadata.json`, and `Predictor.predict()` returning the same JSON shape.
