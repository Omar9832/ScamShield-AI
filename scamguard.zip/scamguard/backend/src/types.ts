export type RiskLevel = "low" | "medium" | "high";

export interface AnalysisResult {
  riskScore: number; // 0-100
  riskLevel: RiskLevel;
  topCategory: string;
  categories: { label: string; probability: number }[];
  signals: { term: string; weight: number }[];
  flags: { id: string; label: string }[];
  modelVersion: string;
}
