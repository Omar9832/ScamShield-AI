import express from "express";
import cors from "cors";
import type { AnalysisResult } from "./types.js";

const PORT = Number(process.env.PORT ?? 4000);
const ML_URL = process.env.ML_URL ?? "http://localhost:8000";

const app = express();
app.use(cors());
app.use(express.json({ limit: "10kb" }));

app.get("/api/health", async (_req, res) => {
  try {
    const r = await fetch(`${ML_URL}/health`);
    res.json({ ok: true, model: await r.json() });
  } catch {
    res.status(503).json({ ok: false, error: "Model service unreachable" });
  }
});

app.post("/api/analyze", async (req, res) => {
  const message = req.body?.message;
  if (typeof message !== "string" || !message.trim() || message.length > 2000) {
    return res.status(400).json({ error: "message must be a non-empty string up to 2000 chars" });
  }
  try {
    const r = await fetch(`${ML_URL}/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: message.trim() }),
    });
    if (!r.ok) throw new Error(`model service returned ${r.status}`);
    const result = (await r.json()) as AnalysisResult;
    // Hook point: log/store results, rate-limit, add rules, A/B test models, etc.
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(502).json({ error: "Analysis failed. Is the model service running?" });
  }
});

app.listen(PORT, () => console.log(`API on :${PORT}, model service at ${ML_URL}`));
