"""Tiny inference service. Run: uvicorn serve:app --port 8000"""
from fastapi import FastAPI
from pydantic import BaseModel, Field
from predict import Predictor

app = FastAPI(title="ScamGuard model service")
predictor = Predictor()   # loaded ONCE at startup, not per request


class In(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


@app.get("/health")
def health():
    return {"ok": True, "modelVersion": predictor.meta["version"]}


@app.post("/predict")
def predict(body: In):
    return predictor.predict(body.text)
