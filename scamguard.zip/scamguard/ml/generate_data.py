"""Generate a SMALL synthetic dataset for the tutorial.
Replace data/messages.csv with the real synthetic set later; train.py only needs columns: text,label
"""
import csv, random, pathlib

random.seed(42)
OUT = pathlib.Path(__file__).parent / "data" / "messages.csv"

SLOTS = {
    "brand": ["Amazon", "USPS", "FedEx", "Netflix", "PayPal", "Apple", "DHL"],
    "bank": ["Chase", "Wells Fargo", "Bank of America", "Citi"],
    "amount": ["$250", "$1,000", "$49.99", "$5,000", "$12.50"],
    "url": ["bit.ly/3xK9a", "secure-login-verify.com", "tinyurl.com/a8Zq", "claim-now.info", "acct-update.net"],
    "name": ["Sam", "Priya", "Mike", "Dana", "Alex", "Jordan"],
    "code": ["482913", "77201", "903357", "118842"],
    "time": ["3pm", "9:30am", "tomorrow at 10", "Friday at 2"],
}

TEMPLATES = {
    "legitimate": [
        "Hey {name}, are we still on for dinner at {time}?",
        "Your verification code is {code}. Do not share it with anyone.",
        "Reminder: your dentist appointment is {time}. Reply C to confirm.",
        "Your {brand} order has shipped and will arrive Thursday. Track in the app.",
        "Thanks for your payment of {amount}. Your receipt is in your email.",
        "Running late, be there in 10 min. Save me a seat!",
        "Hi {name}, can you send me the notes from the meeting?",
        "Your {bank} statement is ready. Log in through the official app to view it.",
    ],
    "phishing": [
        "{brand} security alert: your account is locked. Verify now at {url}",
        "We detected unusual sign-in on your {brand} account. Confirm identity: {url}",
        "Your password expires today. Update immediately at {url} to avoid suspension.",
        "{brand}: payment method declined. Update billing info within 24 hours {url}",
    ],
    "bank_impersonation": [
        "{bank} ALERT: suspicious charge of {amount}. Call us or visit {url} to cancel.",
        "{bank}: your card has been frozen. Verify your PIN and SSN at {url}",
        "Fraud department: {amount} transfer pending. Reply YES to approve or NO to dispute.",
        "{bank} notice: unauthorized login. Secure your account now {url}",
    ],
    "delivery": [
        "{brand}: your package could not be delivered. Pay a $1.99 fee to reschedule {url}",
        "Delivery attempt failed. Confirm your address within 12 hours: {url}",
        "{brand} parcel on hold due to unpaid customs fee. Settle at {url}",
        "Your package is waiting. Update shipping details now {url}",
    ],
    "prize": [
        "Congratulations {name}! You won {amount} in our giveaway. Claim at {url}",
        "You've been selected for a {amount} {brand} gift card. Act now: {url}",
        "WINNER! Claim your free prize before it expires tonight {url}",
        "Final notice: unclaimed reward of {amount} is waiting for you {url}",
    ],
    "advance_fee": [
        "Hello, I am a prince and need your help moving {amount}. You keep 30%. Reply with bank details.",
        "Job offer: earn {amount} a week working from home. Send a deposit to start.",
        "Hi {name}, I'm stuck abroad and need {amount} for a flight. Please send gift cards, I'll repay you.",
        "Investment opportunity with guaranteed 300% returns. Wire {amount} today.",
    ],
}

PER_CLASS = 120
rows = []
for label, temps in TEMPLATES.items():
    for _ in range(PER_CLASS):
        t = random.choice(temps)
        text = t.format(**{k: random.choice(v) for k, v in SLOTS.items()})
        if random.random() < 0.2:
            text = text.upper() if random.random() < 0.3 else text + random.choice([" !!", " Thanks", " ASAP"])
        rows.append((text, label))

random.shuffle(rows)
OUT.parent.mkdir(exist_ok=True)
with open(OUT, "w", newline="") as f:
    w = csv.writer(f); w.writerow(["text", "label"]); w.writerows(rows)
print(f"Wrote {len(rows)} rows to {OUT}")
