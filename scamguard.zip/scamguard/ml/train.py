"""Train the baseline classifier and save a versioned artifact."""
import csv, json, pathlib, time
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

HERE = pathlib.Path(__file__).parent
DATA = HERE / "data" / "messages.csv"
ART = HERE / "artifacts"

with open(DATA) as f:
    rows = list(csv.DictReader(f))
texts = [r["text"] for r in rows]
labels = [r["label"] for r in rows]

# 1. Hold out data the model never sees during training
X_tr, X_te, y_tr, y_te = train_test_split(texts, labels, test_size=0.2, stratify=labels, random_state=0)

# 2. Text -> numbers (TF-IDF over words and word pairs)
vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, min_df=1)
Xv_tr = vec.fit_transform(X_tr)          # fit ONLY on training data

# 3. Learn weights
clf = LogisticRegression(max_iter=1000, class_weight="balanced")
clf.fit(Xv_tr, y_tr)

# 4. Evaluate on held-out data
pred = clf.predict(vec.transform(X_te))
report = classification_report(y_te, pred, output_dict=True, zero_division=0)
print(classification_report(y_te, pred, zero_division=0))

# 5. Save everything inference needs, plus metadata
ART.mkdir(exist_ok=True)
version = time.strftime("%Y%m%d-%H%M%S")
joblib.dump({"vectorizer": vec, "classifier": clf}, ART / "model.joblib")
(ART / "metadata.json").write_text(json.dumps({
    "version": version,
    "classes": list(clf.classes_),
    "n_train": len(X_tr), "n_test": len(X_te),
    "accuracy": report["accuracy"],
    "macro_f1": report["macro avg"]["f1-score"],
}, indent=2))
print(f"Saved model version {version} to {ART}")
