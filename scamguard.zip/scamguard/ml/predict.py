"""Inference logic, independent of any web framework (easy to unit test)."""
import json, pathlib, re
import joblib
import numpy as np

HERE = pathlib.Path(__file__).parent
LEGIT = "legitimate"
URL_RE = re.compile(r"(https?://|www\.|\b[\w-]+\.(com|net|info|org|co)\b|bit\.ly|tinyurl)", re.I)
URGENCY_RE = re.compile(r"\b(urgent|immediately|now|today|expires?|within \d+ hours|final notice|act now|asap)\b", re.I)
MONEY_RE = re.compile(r"[$€£]\s?\d|gift card|wire|bitcoin|crypto", re.I)
SENSITIVE_RE = re.compile(r"\b(pin|ssn|password|social security|bank details|verify)\b", re.I)

FLAGS = [
    ("url", "Contains a link or domain", URL_RE),
    ("urgency", "Uses urgency or deadline pressure", URGENCY_RE),
    ("money", "Mentions money, gift cards or wire transfers", MONEY_RE),
    ("sensitive", "Asks for or mentions sensitive info", SENSITIVE_RE),
]


class Predictor:
    def __init__(self, model_dir: pathlib.Path = HERE / "artifacts"):
        art = joblib.load(model_dir / "model.joblib")
        self.vec, self.clf = art["vectorizer"], art["classifier"]
        self.meta = json.loads((model_dir / "metadata.json").read_text())
        self.classes = list(self.clf.classes_)
        self.legit_i = self.classes.index(LEGIT)
        self.terms = self.vec.get_feature_names_out()

    def predict(self, text: str) -> dict:
        X = self.vec.transform([text])
        proba = self.clf.predict_proba(X)[0]
        risk = float(1.0 - proba[self.legit_i])

        # Most likely scam category (ignore the legit class)
        scam_idx = [i for i in range(len(self.classes)) if i != self.legit_i]
        top_i = max(scam_idx, key=lambda i: proba[i])

        # Explainability: which words pushed toward "scam category" over "legit"
        coef = self.clf.coef_
        row = X.tocoo()
        contrib = [(self.terms[j], float(v * (coef[top_i, j] - coef[self.legit_i, j])))
                   for j, v in zip(row.col, row.data)]
        signals = [{"term": t, "weight": round(w, 3)}
                   for t, w in sorted(contrib, key=lambda x: -x[1]) if w > 0][:6]

        level = "low" if risk < 0.35 else "medium" if risk < 0.7 else "high"
        return {
            "riskScore": round(risk * 100),
            "riskLevel": level,
            "topCategory": self.classes[top_i],
            "categories": sorted(
                [{"label": c, "probability": round(float(p), 4)} for c, p in zip(self.classes, proba)],
                key=lambda x: -x["probability"]),
            "signals": signals,
            "flags": [{"id": i, "label": l} for i, l, rx in FLAGS if rx.search(text)],
            "modelVersion": self.meta["version"],
        }
